r"""Optional IC2 2.2.827 language patch, with version hash check and backup.
Usage: python install_ic2.py --instance "C:\path\to\Sigma" --pack Sigma-Russian.zip
Close Minecraft first. This script does not activate resource packs.
"""
import argparse,hashlib,json,shutil,zipfile,os
from pathlib import Path
def install(instance,pack):
    instance=Path(instance).resolve(strict=True);pack=Path(pack).resolve(strict=True)
    with zipfile.ZipFile(pack) as z:
        manifest=json.loads(z.read('manifest.json'));entry=manifest['ic2'];translation=z.read(entry['path'])
    jar=(instance/'mods'/entry['jar']).resolve(strict=True)
    if jar.parent!=(instance/'mods').resolve():raise ValueError('Unexpected target path')
    expected=entry['sha256'];actual=hashlib.sha256(jar.read_bytes()).hexdigest()
    if actual!=expected:raise ValueError('IC2 JAR differs from the audited version; original file was not changed.')
    backup=instance/'backups'/'sigma-russian'/jar.name;backup.parent.mkdir(parents=True,exist_ok=True)
    if backup.exists():
        if hashlib.sha256(backup.read_bytes()).hexdigest()!=expected:raise ValueError('Conflicting backup exists; nothing changed.')
    else:shutil.copy2(jar,backup)
    tmp=jar.with_suffix('.translation.tmp')
    try:
        with zipfile.ZipFile(jar) as old,zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED) as new:
            for info in old.infolist():new.writestr(info,translation if info.filename==entry['path'] else old.read(info.filename))
        with zipfile.ZipFile(tmp) as test:
            if test.testzip() is not None:raise ValueError('ZIP validation failed')
            if test.read(entry['path'])!=translation:raise ValueError('Translation verification failed')
        os.replace(tmp,jar)
    finally:
        if tmp.exists():tmp.unlink()
    print('IC2 translation installed. Backup:',backup)
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--instance',required=True);parser.add_argument('--pack',required=True)
    args=parser.parse_args();install(args.instance,args.pack)
