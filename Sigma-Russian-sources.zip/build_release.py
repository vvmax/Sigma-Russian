from pathlib import Path
import zipfile, hashlib

root = Path(__file__).resolve().parent
downloads = root / 'downloads'
downloads.mkdir(exist_ok=True)
pack = downloads / 'Sigma-Russian.zip'
with zipfile.ZipFile(pack, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in sorted((root / 'resourcepack').rglob('*')):
        if p.is_file():
            z.write(p, p.relative_to(root / 'resourcepack').as_posix())
addon = downloads / 'SigmaRussian-Tooltips-1.7.10-1.0.0.jar'
complete = downloads / 'Sigma-Russian-complete.zip'
with zipfile.ZipFile(complete, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in [pack, addon, root / 'README.md', root / 'SOURCES.md', root / 'REPORT.md', root / 'install_ic2.py']:
        z.write(p, p.name)
    for p in sorted((root / 'data').glob('*')):
        z.write(p, 'data/' + p.name)
for p in [pack, addon, complete]:
    with zipfile.ZipFile(p) as z:
        assert z.testzip() is None
(downloads / 'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.name + '\n' for p in [pack, addon, complete]), encoding='ascii')
print('Built and verified three archives.')
