package sigma.localization;

import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.FMLCommonHandler;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.eventhandler.EventPriority;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;

@Mod(modid="sigmarussian", name="Sigma Russian Tooltips", version="1.0.0", acceptableRemoteVersions="*")
public final class SigmaRussianTooltips {
    @EventHandler public void init(FMLInitializationEvent event) { MinecraftForge.EVENT_BUS.register(this); }
    @SubscribeEvent(priority=EventPriority.LOWEST)
    public void tooltip(ItemTooltipEvent event) {
        String language = FMLCommonHandler.instance().getCurrentLanguage();
        if (!"ru_RU".equalsIgnoreCase(language)) return;
        for (int i=0; i<event.toolTip.size(); i++) {
            String old=event.toolTip.get(i);
            String translated=TooltipTranslator.translate(old, language);
            if (!old.equals(translated)) event.toolTip.set(i, translated);
        }
    }
}
