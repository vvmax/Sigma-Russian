package sigma.localization;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

public final class TooltipTranslator {
    private static final Properties TEXT = new Properties();
    static {
        try (InputStream in = TooltipTranslator.class.getResourceAsStream("/assets/sigma_russian/tooltips/ru_RU.properties")) {
            if (in == null) throw new IllegalStateException("Missing tooltip translations");
            TEXT.load(new InputStreamReader(in, StandardCharsets.UTF_8));
        } catch (Exception ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }
    private TooltipTranslator() {}
    public static String translate(String line, String language) {
        if (line == null || !"ru_RU".equalsIgnoreCase(language)) return line;
        String clean = line.replaceAll("\u00a7[0-9A-FK-ORa-fk-or]", "");
        String exact = TEXT.getProperty(clean);
        if (exact != null) {
            StringBuilder colour = new StringBuilder();
            for (int i = 0; i + 1 < line.length() && line.charAt(i) == '\u00a7'; i += 2) colour.append(line, i, i + 2);
            return colour + exact;
        }
        String result = line;
        if (clean.startsWith("Fills ") && clean.endsWith(" Hunger Bars"))
            result = result.replace("Fills ", "Восстанавливает ").replace(" Hunger Bars", " ед. сытости");
        else if (clean.matches("[-+0-9.,]+ Saturation"))
            result = result.replace(" Saturation", " ед. насыщения");
        else if (clean.startsWith("Pet Food:"))
            result = result.replace("Pet Food:", "Корм для питомца:").replace("false", "нет").replace("False", "нет").replace("true", "да").replace("True", "да");
        else if (clean.startsWith("Heals ") && clean.endsWith(" hearts on use"))
            result = result.replace("Heals ", "Восстанавливает ").replace(" hearts on use", " сердец при использовании");
        else if (clean.startsWith("Replenishes ") && clean.endsWith(" Hunger"))
            result = result.replace("Replenishes ", "Восстанавливает ").replace(" Hunger", " ед. сытости");
        else if (clean.matches("[-+0-9.,]+ Health")) result = result.replace(" Health", " ед. здоровья");
        else if (clean.matches("[-+0-9.,]+ Damage")) result = result.replace(" Damage", " ед. урона");
        else if (clean.matches("[-+0-9.,]+ Times Faster")) result = result.replace(" Times Faster", " раз быстрее");
        else if (clean.matches("[-+0-9.,]+ Times Slower")) result = result.replace(" Times Slower", " раз медленнее");
        else if (clean.startsWith("Spawns a pet ")) result = result.replace("Spawns a pet ", "Призывает питомца: ").replace(" Grizzle", " Гриззл");
        return result;
    }
}
