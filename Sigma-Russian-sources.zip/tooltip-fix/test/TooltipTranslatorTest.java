import sigma.localization.TooltipTranslator;
public final class TooltipTranslatorTest {
    static void check(String input,String expected) {
        String got=TooltipTranslator.translate(input,"ru_RU");
        if (!expected.equals(got)) throw new AssertionError(input+" -> "+got);
        if (!input.equals(TooltipTranslator.translate(input,"en_US"))) throw new AssertionError("English was modified");
    }
    public static void main(String[] args) {
        check("Fills 0.5 Hunger Bars","Восстанавливает 0.5 ед. сытости");
        check("1.0 Saturation","1.0 ед. насыщения");
        check("\u00a79Pet Food:\u00a7r false","\u00a79Корм для питомца:\u00a7r нет");
        check("\u00a79Pet Food:\u00a7r true","\u00a79Корм для питомца:\u00a7r да");
        check("Pet Food: False","Корм для питомца: нет");
        check("Gives Speed and Water Breathing for 30 seconds.","Даёт скорость и подводное дыхание на 30 секунд.");
        check("\u00a77Gives Speed and Water Breathing for 30 seconds.","\u00a77Даёт скорость и подводное дыхание на 30 секунд.");
        check("Heals 2.0 hearts on use","Восстанавливает 2.0 сердец при использовании");
        check("13 Damage","13 ед. урона");
        check("20 Health","20 ед. здоровья");
        check("Unrelated text is untouched","Unrelated text is untouched");
        System.out.println("PASS: 11 Russian tooltip fixtures; English unchanged; formatting and numeric values preserved");
    }
}
